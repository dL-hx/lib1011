/*!
 * artTemplate[NodeJS]
 * https://github.com/aui/artTemplate
 * Released under the MIT, BSD, and GPL Licenses
 */

var node = require('./_node.js');
var template = require('../dist/template-debug.js');
module.exports = node(template);