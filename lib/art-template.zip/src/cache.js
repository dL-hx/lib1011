var cacheStore = template.cache = {};


