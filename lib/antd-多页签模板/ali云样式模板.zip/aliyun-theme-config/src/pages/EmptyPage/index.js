import React, {Component} from 'react';

class Index extends Component {
  render() {
    return (
      <div>
        1
      </div>
    );
  }
}

export default Index;
