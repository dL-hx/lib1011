import React, {Component} from 'react';

class Index extends Component {
  render() {
    return (
      <div>
        qqq
      </div>
    );
  }
}

export default Index;
