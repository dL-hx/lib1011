
export default{
    'GET /fsc/budget/expense/list': {
        success:true,
        code:200,
        datas:[
          {
            key: '1',
            name: 'John Brown',
            age: 32,
            address: 'New York No. 1 Lake Park',
          },
        ],
    },
}