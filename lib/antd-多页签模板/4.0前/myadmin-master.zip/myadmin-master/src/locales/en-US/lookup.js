export default {
    'lookup.sm.user.title':'选择用户',
}