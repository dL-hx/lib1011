import React from 'react';

/**
 * @desc 查看页面通用样式
 */
export default ({ children }) => {
  return <div>{children}</div>;
};
