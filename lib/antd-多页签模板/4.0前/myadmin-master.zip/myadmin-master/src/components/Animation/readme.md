### 动画组

### BgCL
带有圆和竖线的动画

#### 使用
```javascript
import { BgCL } from '@/components/Animation'

<BgCL>
html        
</BgCl>

```