---
title: WConfirm
subtitle: 通用确认弹框
desc: 
---

## Tag使用
import WConfirm from 'components/WConfirm/WConfirm'


 return （
  <WConfirm type="del" disabled>
    <a href=" #! ">删除</a>
  </WConfirm>
 ）

## API

| 参数      | 说明                                      | 类型         | 默认值 |
|----------|------------------------------------------|-------------|-------|
type    指定提示类型 详情参考 configMap配置
disabled 是否禁用
title   国际化的key     string    非必填




