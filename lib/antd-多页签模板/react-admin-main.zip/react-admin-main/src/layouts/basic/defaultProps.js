export const siderWidth = 256;
export const collapsedWidth = 80