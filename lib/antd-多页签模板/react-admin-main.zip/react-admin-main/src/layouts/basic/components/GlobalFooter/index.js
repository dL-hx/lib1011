import React from 'react';
import './index.less';

const GlobalFooter = () => {
  return (
    <div className="global-footer">
      {/* Ant Design ©2018 Created by Ant UED */}
      中孚信息股份有限公司
    </div>
  )
}

export default GlobalFooter