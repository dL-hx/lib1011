import React from 'react';

const Test = () => {
  return (
    <h2>测试文件</h2>
  )
}

export default Test;