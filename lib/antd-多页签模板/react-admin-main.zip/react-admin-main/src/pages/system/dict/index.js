import React from 'react';

const SystemDict = () => {
  return (
    <h2>字典管理</h2>
  )
}

export default SystemDict;