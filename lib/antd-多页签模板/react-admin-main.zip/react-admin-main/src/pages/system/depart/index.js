import React from 'react';

const SystemDepart = () => {
  return (
    <h2> 部门管理 </h2>
  )
}

export default SystemDepart;