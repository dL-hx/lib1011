import React from 'react';

const SystemMenu = () => {
  return (
    <h2>菜单管理</h2>
  )
}

export default SystemMenu;