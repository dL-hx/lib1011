import React from 'react';

const SystemRole = () => {
  return (
    <h2>角色管理</h2>
  )
}

export default SystemRole;