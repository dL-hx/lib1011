import React from "react";
import { Link } from 'react-router-dom';

const FrontEnd = () => {
  return (
    <div> 
      <h2> menu-1-2 </h2>
      <Link to="/"> 首页 </Link>
    </div>
  )
}

export default FrontEnd;