import React from "react";
import { Link } from 'react-router-dom';

const BackEnd = () => {

  return (
    <div>
      <h2> menu-2 </h2>
      <Link to="/"> 首页 </Link>
    </div>
  )
}

export default BackEnd;