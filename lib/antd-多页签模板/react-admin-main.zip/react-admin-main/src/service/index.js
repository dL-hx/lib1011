import user from './user'
import demo from './demo'

export default {
  user,
  demo
}