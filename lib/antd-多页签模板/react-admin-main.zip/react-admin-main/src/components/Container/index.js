import GridContent from './GridContent'

export default { GridContent }