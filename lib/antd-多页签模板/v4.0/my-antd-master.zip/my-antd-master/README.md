# My-Antd

针对 [Ant Design Pro](https://pro.ant.design). 进行了个性化处理

[Github](https://github.com/Wen006/my-antd.git)
[Gitee](https://gitee.com/W006/my-antd.git)

## 修改点

- 支持菜单多切页和面包屑切换
- 路由抽取

---

- 企业应用组件封装 （进行中）
- 其他。。。
  
## 参考图片

<img src="doc/tab-0001.jpg" alt="tab-0001" style="zoom:50%;" />

<img src="doc/tab-0002.jpg" alt="tab-0001" style="zoom:50%;" />

<img src="doc/tab-0003.jpg" alt="tab-0001" style="zoom:50%;" />

<img src="doc/tab-0004.jpg" alt="tab-0001" style="zoom:50%;" />