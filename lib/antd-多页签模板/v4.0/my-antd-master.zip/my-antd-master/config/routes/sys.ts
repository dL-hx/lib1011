
export default[
    {
        path: '/func',
        name: 'Func测试',
        icon: 'smile',
        component: './demo/FuncDemo',
    },
    {
        path: '/class',
        name: 'Class测试',
        icon: 'smile',
        component: './demo/ClazzDemo',
    },
]