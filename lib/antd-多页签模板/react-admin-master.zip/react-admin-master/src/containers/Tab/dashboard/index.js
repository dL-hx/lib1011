import React, { Component } from 'react';
import styles from "./index.scss";
import { hot } from 'react-hot-loader'

class Index extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                建设中
            </div>
        );
    }
}
export default hot(module)(Index);