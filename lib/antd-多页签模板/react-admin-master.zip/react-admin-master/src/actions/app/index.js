import { TOGGLE_MENU_COLLAPSED } from 'constants/app'

export const toggleMenuCollapsed = state => ({
  type: TOGGLE_MENU_COLLAPSED,
  state
})
