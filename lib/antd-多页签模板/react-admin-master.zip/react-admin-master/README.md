# React Admin

> A React project

## Build Setup

``` bash
# 安装依赖
yarn 

# 启动运行在 localhost:8888 带热加载前端工程
yarn start

# 打包
yarn run build

```