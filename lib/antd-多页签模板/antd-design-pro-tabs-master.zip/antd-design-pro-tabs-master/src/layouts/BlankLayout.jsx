import React from 'react';

const Layout = ({ children }) => <>{children}</>;

export default Layout;
