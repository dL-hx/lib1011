---
name: "\U0001F680 Feature Request"
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**描述你希望的支持的新功能？**

**你期望的 API 是怎样的？**
