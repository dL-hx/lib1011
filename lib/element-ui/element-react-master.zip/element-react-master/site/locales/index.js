
export default {
  'zh-CN': require('./zh-CN'),
  'en-US': require('./en-US')
}
