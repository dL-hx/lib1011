declare module 'popper.js' {
  declare export default any;
}

declare module 'classnames' {
  declare var exports: {
    (): any
  }
}

declare module 'react-click-outside' {
  declare module.exports: any;
}

declare module 'throttle-debounce' {
  declare var debounce: any;
  declare var throttle: any;
}

declare module 'async-validator' {
  declare export default any;
}
