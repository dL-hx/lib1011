/*
this is trimmed version compared to the version in vue-element lib.
native functionality are leftout.

revision version:
  48996c6658300b7f9f01b9b4011a531f17e30b75
*/
export {Scrollbar} from './Scrollbar'