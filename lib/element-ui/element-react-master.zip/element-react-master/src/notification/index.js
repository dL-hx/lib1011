import NotificationCenter from './NotificationCenter';

export default NotificationCenter;
