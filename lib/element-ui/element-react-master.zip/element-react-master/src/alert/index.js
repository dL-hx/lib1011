import Alert from './Alert';

export default Alert;
