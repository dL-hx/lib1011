import Row from './Row';
import Col from './Col';

export default {
  Row,
  Col
}
