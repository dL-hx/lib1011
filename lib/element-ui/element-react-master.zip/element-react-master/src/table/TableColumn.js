// import * as React from 'react';
// import { Component, PropTypes } from '../../libs';

function TableColumn() {
  return null;
}

TableColumn.typeName = 'TableColumn';

export default TableColumn;