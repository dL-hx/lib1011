import Tag from './Tag'

export default Tag
