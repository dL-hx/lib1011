import Form from './Form';
import FormItem from './FormItem';

Form.Item = FormItem;

export default Form;
