export default {
  plugins: ['umi-plugin-autolayout'],
};

