# swr

## Links

* https://swr.now.sh/
* https://github.com/zeit/swr

