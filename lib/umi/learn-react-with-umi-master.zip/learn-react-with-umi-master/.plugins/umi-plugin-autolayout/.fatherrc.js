
export default {
  target: 'browser',
  cjs: 'babel',
}
