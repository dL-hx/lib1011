# @umijs/plugin-model

## Links

* https://github.com/umijs/plugin-model
