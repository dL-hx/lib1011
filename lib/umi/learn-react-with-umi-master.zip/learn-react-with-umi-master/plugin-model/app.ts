
export async function getInitialState() {
  return 'Hello world';
}
