---
translateHelp: true
---

# @umijs/plugin-preact


切换 react 为 preact。

## 启用方式

默认开启。

## 注意

* 你使用的 ui 库可能不兼容 preact，比如 antd
