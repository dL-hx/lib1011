export { getExportProps } from './getExportProps/getExportProps';
export { isReactComponent } from './isReactComponent/isReactComponent';
