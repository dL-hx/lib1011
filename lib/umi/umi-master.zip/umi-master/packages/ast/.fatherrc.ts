export default {
  disableTypeCheck: false,
};
