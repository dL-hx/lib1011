//@ts-ignore
import('./a');
console.log('index');
