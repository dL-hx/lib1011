export default {
  devtool: false,
  dynamicImport: true,
};
