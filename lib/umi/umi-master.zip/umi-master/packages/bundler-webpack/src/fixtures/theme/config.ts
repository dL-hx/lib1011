export default {
  theme: {
    red: 'green',
  },
};
