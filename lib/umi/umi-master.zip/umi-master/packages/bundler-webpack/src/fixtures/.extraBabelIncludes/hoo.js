
export default function() {
  let hoo = 1;
  hoo += 1;
  return hoo;
}
