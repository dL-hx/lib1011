import 'foo';
import 'react';
import 'react-intl';
