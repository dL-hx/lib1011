export default {
  alias: {
    react: require.resolve('./react.ts'),
  },
  nodeModulesTransform: {
    type: 'none',
  },
};
