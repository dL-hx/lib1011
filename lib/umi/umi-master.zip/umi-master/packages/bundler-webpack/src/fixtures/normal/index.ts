const a: string = 'a';
console.log(a);
