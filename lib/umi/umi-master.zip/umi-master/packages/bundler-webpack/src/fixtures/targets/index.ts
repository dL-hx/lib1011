class A {
  render() {
    return 'a';
  }
}

export default A;
