export default {
  externals: {
    react: 'React',
  },
};
