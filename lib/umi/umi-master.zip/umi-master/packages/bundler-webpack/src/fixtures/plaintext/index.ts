// @ts-ignore
import foo from './foo.md';
// @ts-ignore
import bar from './bar.txt';
console.log(foo);
console.log(bar);
