import styles from './style.less';
import styles2 from './style2.css';

const classname = styles.a;

const classname2 = styles2.test;
