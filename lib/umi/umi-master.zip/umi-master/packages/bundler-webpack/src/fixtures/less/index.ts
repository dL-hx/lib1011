import './a.less';
import styles from './b.less';

console.log(styles);
