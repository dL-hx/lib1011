
export default () => {
  let too = 1;
  too += 1;
  return too;
}
