export default {
  runtimePublicPath: true,
};
