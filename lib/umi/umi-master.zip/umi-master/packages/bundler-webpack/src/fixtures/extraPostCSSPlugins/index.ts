import styles from './a.less';

console.log(styles);
