export default {
  outputPath: 'bar',
};
