export default {
  targets: {
    ie: 10,
  },
};
