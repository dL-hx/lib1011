import { ReactComponent as Icon } from './logo.svg';
export default () => <Icon />;
