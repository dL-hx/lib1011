export default {
  cssModulesTypescriptLoader: {},
};
