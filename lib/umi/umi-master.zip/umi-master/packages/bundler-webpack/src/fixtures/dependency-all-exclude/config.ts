export default {
  nodeModulesTransform: {
    type: 'all',
    exclude: ['foo'],
  },
};
