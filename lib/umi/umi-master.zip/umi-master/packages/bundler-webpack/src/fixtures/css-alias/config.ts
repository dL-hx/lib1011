export default {
  alias: {
    bbb: require.resolve('./bar.css'),
  },
};
