const a = 'react';
export default a;
