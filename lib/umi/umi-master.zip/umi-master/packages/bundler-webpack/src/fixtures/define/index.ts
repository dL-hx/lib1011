//@ts-ignore
console.log(FOO);
//@ts-ignore
console.log(a.FOO);
console.log(process.env.FOO);
console.log(process.env.NODE_ENV);
