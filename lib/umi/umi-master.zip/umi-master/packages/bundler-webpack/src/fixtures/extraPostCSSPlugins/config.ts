const plugin = require('./plugin');

export default {
  extraPostCSSPlugins: [plugin()],
};
