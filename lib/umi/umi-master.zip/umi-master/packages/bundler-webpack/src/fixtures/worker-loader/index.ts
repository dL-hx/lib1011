//@ts-ignore
import Worker from './worker';

const worker = new Worker();
worker.postMessage('aaaa');
