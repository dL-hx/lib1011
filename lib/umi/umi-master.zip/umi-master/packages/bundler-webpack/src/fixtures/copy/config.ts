export default {
  copy: [
    'b.ts',
    {
      from: 'c.ts',
      to: '',
    },
    {
      from: 'utils/d.ts',
      to: '',
    },
  ],
};
