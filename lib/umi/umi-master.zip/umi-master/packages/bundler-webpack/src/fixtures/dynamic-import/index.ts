// @ts-ignore
import('./a');
// @ts-ignore
import(/* webpackChunkName: "b" */ './b');
