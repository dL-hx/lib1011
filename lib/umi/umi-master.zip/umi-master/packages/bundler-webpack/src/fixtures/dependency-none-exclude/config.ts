export default {
  nodeModulesTransform: {
    type: 'none',
    exclude: ['react-intl'],
  },
};
