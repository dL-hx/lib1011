export default {
  define: {
    FOO: '1',
    'a.FOO': '2',
    'process.env.FOO': '3',
  },
};
