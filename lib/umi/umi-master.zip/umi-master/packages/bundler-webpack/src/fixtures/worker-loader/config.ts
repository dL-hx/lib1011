export default {
  workerLoader: {},
};
