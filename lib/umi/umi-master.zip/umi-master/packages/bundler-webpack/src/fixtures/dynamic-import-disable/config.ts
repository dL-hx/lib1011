export default {
  dynamicImport: false,
};
