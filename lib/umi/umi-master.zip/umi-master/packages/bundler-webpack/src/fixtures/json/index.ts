import react from './react.json';
console.log(react);
