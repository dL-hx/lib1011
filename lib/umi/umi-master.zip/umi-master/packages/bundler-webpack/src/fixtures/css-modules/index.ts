import './a.css';
import styles from './b.css';
import empty from './empty.less';

console.log(styles.b);
console.log(empty.container);
