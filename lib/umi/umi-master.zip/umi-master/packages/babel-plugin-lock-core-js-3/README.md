# @umijs/babel-plugin-lock-core-js-3
