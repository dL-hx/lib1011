import React from 'react';
import styles from './list.less';

export default () => {
  return (
    <div>
      <h1 className={styles.title}>Page list</h1>
    </div>
  );
};
