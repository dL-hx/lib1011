import { defineConfig } from 'umi';

export default defineConfig({
  favicon: './favicon.png',
});
