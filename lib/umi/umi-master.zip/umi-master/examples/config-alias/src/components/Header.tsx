import type { FC } from 'react';
import React from 'react';

const Header: FC = () => {
  return <h1>Header: Config alias</h1>;
};

export default Header;
