import type { FC } from 'react';
import React from 'react';

const Footer: FC = () => {
  return <div>Footer: Open-source MIT Licensed | Copyright © 2017-present</div>;
};

export default Footer;
