import React from 'react';

const Home = (props) => {
  return <div>Hello World</div>;
};

export default Home;
