import React from 'react';

const LoginPage = () => {
  return (
    <div>
      <h1>Login Page</h1>
      <p>Hi,you're here,We have a 'wrappers' in IndexPage.</p>
    </div>
  );
};

export default LoginPage;
