export default {
  dynamicImport: {},
};
