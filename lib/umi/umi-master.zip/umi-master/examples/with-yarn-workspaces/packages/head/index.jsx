import React from 'react';

const Head = () => <h1 style={{ fontSize: '48px' }}>UmiJS</h1>;

export default Head;
