import React from 'react';

const Footer = () => (
  <div>Open-source MIT Licensed | Copyright © 2017-present</div>
);

export default Footer;
