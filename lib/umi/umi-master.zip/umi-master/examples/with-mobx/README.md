# with-mobx

umi with [mobx](https://github.com/mobxjs/mobx) - Simple, scalable state management..

## How to use

Execute [`@umijs/create-umi-app`](https://github.com/umijs/umi/tree/master/packages/create-umi-app) with [npm](https://docs.npmjs.com/cli/init) or [Yarn](https://yarnpkg.com/lang/en/docs/cli/create/) to bootstrap the example:

```bash
npx @umijs/create-umi-app --example with-mobx with-mobx-app
# or
yarn create @umijs/umi-app --example with-mobx with-mobx-app
```
