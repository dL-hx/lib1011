export const ssr = {};
