export default {
  umi: 'hello umi',
};
