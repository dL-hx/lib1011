export default {
  umi: '你好 乌米',
};
