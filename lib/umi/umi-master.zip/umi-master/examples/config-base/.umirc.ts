import { defineConfig } from 'umi';

export default defineConfig({
  base: '/some',
});
