export async function getInitialState() {
  const data = {
    username: 'xiaohuoni'
  };
  return data;
}