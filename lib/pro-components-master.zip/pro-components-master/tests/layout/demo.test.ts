import demoTest from '../demo';

demoTest('layout');
