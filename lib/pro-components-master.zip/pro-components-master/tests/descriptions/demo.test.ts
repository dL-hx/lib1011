import demoTest from '../demo';

demoTest('descriptions');
