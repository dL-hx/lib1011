import demoTest from '../demo';

demoTest('skeleton');
