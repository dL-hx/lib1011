import demoTest from '../demo';

demoTest('form');
