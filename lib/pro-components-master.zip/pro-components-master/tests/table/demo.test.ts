import demoTest from '../demo';

demoTest('table');
