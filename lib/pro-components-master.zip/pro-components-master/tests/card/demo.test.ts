import demoTest from '../demo';

demoTest('card');
