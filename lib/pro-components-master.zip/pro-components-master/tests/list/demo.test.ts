import demoTest from '../demo';

demoTest('list');
