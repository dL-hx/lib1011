# @umijs/plugin-field

> Umi plugin for access management..

See our website [@ant-design/pro-field](https://procomponent.ant.design/) for more information.

## Install

Using npm:

```bash
$ npm install --save  @ant-design/pro-field
```

or using yarn:

```bash
$ yarn add  @ant-design/pro-field
```
