# @ant-design/pro-card

> @ant-design/pro-card.

See our website [@ant-design/pro-card](https://procomponent.ant.design/) for more information.

## Install

Using npm:

```bash
$ npm install --save  @ant-design/pro-card
```

or using yarn:

```bash
$ yarn add @ant-design/pro-card
```
