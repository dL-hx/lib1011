import PageLoading from './components/PageLoading';

export default PageLoading;
