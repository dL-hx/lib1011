declare module '*.module.less';
