# @ant-design/pro-form

## Install

Using npm:

```bash
$ npm install --save  @ant-design/pro-form
```

or using yarn:

```bash
$ yarn add @ant-design/pro-form
```
