const isNil = (value: any) => value === null || value === undefined;

export default isNil;
