# @ant-design/pro-utils

> @ant-design/pro-utils.

See our website [@ant-design/pro-utils](https://procomponent.ant.design/) for more information.

## Install

Using npm:

```bash
$ npm install --save  @ant-design/pro-utils
```

or using yarn:

```bash
$ yarn add @ant-design/pro-utils
```
