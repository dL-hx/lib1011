# @ant-design/pro-provider

> @ant-design/pro-provider.

See our website [@ant-design/pro-provider](https://procomponent.ant.design/) for more information.

## Install

Using npm:

```bash
$ npm install --save  @ant-design/pro-provider
```

or using yarn:

```bash
$ yarn add @ant-design/pro-provider
```
