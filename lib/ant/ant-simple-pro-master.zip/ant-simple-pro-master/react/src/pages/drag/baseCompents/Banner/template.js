const template = {
  type: 'Banner',
  h: 400,
  w:600,
  title: '轮播组件',
};
export default template;
