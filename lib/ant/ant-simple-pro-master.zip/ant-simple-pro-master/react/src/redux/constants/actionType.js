export const GETMENUTREE='GETMENUTREE'; // 权限树获取

export const LOADING_MENU_TREE='LOADING_MENU_TREE'; // 是否加载出权限tree

export const GETMENULIST='GETMENULIST'; // 权限

export const LOADING_START='LOADING_START'; // loading

export const LOADING_END='LOADING_END';

export const GET_USER_LIST='GET_USER_LIST';

export const GET_USER_INFO='GET_USER_INFO';

export const LOADING_USER_INFO='LOADING_USER_INFO';
