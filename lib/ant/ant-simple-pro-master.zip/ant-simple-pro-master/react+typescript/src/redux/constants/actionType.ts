export const GETMENUTREE='GETMENUTREE'; // 权限树获取
export type GETMENUTREE=typeof GETMENUTREE; // 权限树获取

export const LOADING_MENU_TREE='LOADING_MENU_TREE'; // 是否加载出权限tree
export type LOADING_MENU_TREE=typeof LOADING_MENU_TREE; 

export const GETMENULIST='GETMENULIST'; // 权限
export type GETMENULIST=typeof GETMENULIST; 

export const LOADING_START='LOADING_START'; // loading
export type LOADING_START=typeof LOADING_START; 

export const LOADING_END='LOADING_END';  
export type LOADING_END=typeof LOADING_END;  
  
export const GET_USER_LIST='GET_USER_LIST';  
export type GET_USER_LIST=typeof GET_USER_LIST;  

export const GET_USER_INFO='GET_USER_INFO';  
export type GET_USER_INFO=typeof GET_USER_INFO;  

export const LOADING_USER_INFO='LOADING_USER_INFO';  
export type LOADING_USER_INFO=typeof LOADING_USER_INFO;  