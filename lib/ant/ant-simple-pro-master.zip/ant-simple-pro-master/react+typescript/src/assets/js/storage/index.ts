export {default as localStorage} from './localStorage';

export {default as sessionStorage} from './sessionStorage';