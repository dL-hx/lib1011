export {default as Head} from './head';
export {default as SlideNav} from './slideNav';
export {default as Tag} from './tag';
export {default as Footer} from './footer';
export {default as BackTop} from './backTop';
export {default as News} from './new';
