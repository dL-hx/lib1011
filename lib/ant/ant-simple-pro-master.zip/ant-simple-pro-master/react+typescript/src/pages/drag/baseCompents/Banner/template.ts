const template = {
  type: 'Banner',
  h: 400,
  w:600,
  title: '轮播组件',
  a:145
};
export default template;
