export const spacing = 50; // x,y,w,h,之间的间距

export const clintWidth = 1200; // 画布的可视width
