const template = {
  type: 'News',
  h: 50,
  w:300,
  title: '消息组件',
};
export default template;
