const template = {
  type: 'List',
  w:450,
  h:250,
  title: '列表组件',
};
export default template;
