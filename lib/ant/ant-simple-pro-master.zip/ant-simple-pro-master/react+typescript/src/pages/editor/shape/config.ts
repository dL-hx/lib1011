export const portsCircles = {
  circle: {
    r: 6,
    magnet: true,
    stroke: '#31d0c6',
    strokeWidth: 2,
    fill: '#fff',
    style: {
      visibility: 'hidden',
    },
  }
};
