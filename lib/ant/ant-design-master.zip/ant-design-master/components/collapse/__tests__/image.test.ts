import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('Collapse image', () => {
  imageDemoTest('collapse');
});
