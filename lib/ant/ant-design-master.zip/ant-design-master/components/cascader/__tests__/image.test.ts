import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('Cascader image', () => {
  imageDemoTest('cascader');
});
