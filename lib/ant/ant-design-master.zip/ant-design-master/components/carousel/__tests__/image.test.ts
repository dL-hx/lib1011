import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('Carousel image', () => {
  imageDemoTest('carousel');
});
