import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('Alert image', () => {
  imageDemoTest('alert');
});
