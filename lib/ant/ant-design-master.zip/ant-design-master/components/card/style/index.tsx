import '../../style/index.less';
import './index.less';

// style dependencies
import '../../tabs/style';
import '../../row/style';
import '../../col/style';
