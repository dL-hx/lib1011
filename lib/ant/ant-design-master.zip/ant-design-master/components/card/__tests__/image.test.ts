import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('Card image', () => {
  imageDemoTest('card');
});
