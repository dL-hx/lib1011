import nlNL from '../../date-picker/locale/nl_NL';

export default nlNL;
