import elGR from '../../date-picker/locale/el_GR';

export default elGR;
