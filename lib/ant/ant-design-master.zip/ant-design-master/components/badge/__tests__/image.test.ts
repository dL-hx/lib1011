import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('Badge image', () => {
  imageDemoTest('badge');
});
