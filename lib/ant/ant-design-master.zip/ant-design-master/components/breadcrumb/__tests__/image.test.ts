import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('Breadcrumb image', () => {
  imageDemoTest('breadcrumb', { skip: ['router-4.md'] });
});
