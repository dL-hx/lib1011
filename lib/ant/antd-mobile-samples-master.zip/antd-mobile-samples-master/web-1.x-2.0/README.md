# antd-mobile with webpack

1.x-2.0 升级示例

### Install & Start

```shell
npm i
npm start
```

open http://localhost:8000/
