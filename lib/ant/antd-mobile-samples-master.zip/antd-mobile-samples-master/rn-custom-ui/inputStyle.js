import inputItemStyle from 'antd-mobile-rn/lib/input-item/style/index.native';

export default {
  ...inputItemStyle,
  input: {
    flex: 1,
    fontSize: 12,
  },
}
