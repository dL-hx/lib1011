import Demo from './index.ios.js'

AppRegistry.registerComponent('rncustomui', () => Demo);
