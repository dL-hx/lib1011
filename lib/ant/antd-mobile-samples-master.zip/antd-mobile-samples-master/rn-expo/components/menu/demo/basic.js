import { Menu } from 'antd-mobile-rn'
import React from 'react'

export default class MenuExample extends React.Component {
  render () {
    return (<Menu />)
  }
}
