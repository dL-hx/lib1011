export default {
  prevText: '上一页',
  nextText: '下一页'
}
