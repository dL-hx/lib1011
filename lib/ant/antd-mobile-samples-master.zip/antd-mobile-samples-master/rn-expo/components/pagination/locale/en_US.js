export default {
  prevText: 'Prev',
  nextText: 'Next'
}
