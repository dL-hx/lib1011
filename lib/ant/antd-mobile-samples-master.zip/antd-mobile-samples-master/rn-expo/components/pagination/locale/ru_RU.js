export default {
  prevText: 'Назад',
  nextText: 'Вперёд'
}
