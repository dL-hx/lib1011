import DatePickerLocale from 'rmc-date-picker/lib/locale/ru_RU'
export default {
  okText: 'Ок',
  dismissText: 'Отмена',
  extra: 'Пожалуйста, выберите',
  DatePickerLocale
}
