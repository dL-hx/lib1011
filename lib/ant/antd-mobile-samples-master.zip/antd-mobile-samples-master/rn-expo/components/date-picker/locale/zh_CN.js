import DatePickerLocale from 'rmc-date-picker/lib/locale/zh_CN'
export default {
  okText: '确定',
  dismissText: '取消',
  extra: '请选择',
  DatePickerLocale
}
