import DatePickerLocale from 'rmc-date-picker/lib/locale/en_US'
export default {
  okText: 'OK',
  dismissText: 'Cancel',
  extra: 'please select',
  DatePickerLocale
}
