# antd-mobile-web

Now support antd-mobile@1.x, please see https://github.com/ant-design/antd-mobile-samples/tree/1.x/antd-mobile-web