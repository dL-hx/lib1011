## antd-mobile demo with roadhog, dva

> upgrade from antd-mobible@1.x

Include below common usage:

- custom svg config
- rem config
- custom theme config

### dev

```
npm install
npm start
```

http://localhost:8000/

