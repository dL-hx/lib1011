---
category: Components
type: Biz
title: ScrollView
subtitle: 滚动视图
---


滚动视图


## API  

| 成员        | 说明           | 类型      | 默认值       |
|------------|----------------|--------------------|--------------|
|        |    |  |  |
