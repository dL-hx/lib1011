import Stepper from 'antd-mobile/lib/stepper/index';

export default Stepper;
