---
category: Components
type: Biz
title: PasswordInput
---


## API

### PasswordInput

| 成员        | 说明    | 类型      | 默认值       |
|------------|---------|---------|--------------|
|       |        |      String         |  |

