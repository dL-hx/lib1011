---
category: Components
type: Biz
title: PasswordInput
subtitle: 密码输入框
---


## API

### PasswordInput

| 成员        | 说明    | 类型      | 默认值       |
|------------|---------|---------|--------------|
|       |        |      String         |  |

