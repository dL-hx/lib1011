import Button from 'antd-mobile/lib/button/index';

export default Button;
