---
order: 2
title: 更新日志
---

## 0.1.0
- PageResult 组件更名为 Result

## 0.0.4

文件全部更新到 tsx，兼容 ES6，兼容 antd tools

## 0.0.3

antd-mobile 依赖更新到 `^1.0.0-alpha.4`

## 0.0.2

透传了 antd-mobile 的基础组件

## 0.0.1

hello world!
