# antd-mobile with webpack

webpack@1 is out of date. So please see latest webpack demo [here](https://github.com/ant-design/antd-mobile-samples/tree/master/web-webpack3)
