(window.webpackJsonp = window.webpackJsonp || []).push([
  [8],
  {
    368: function(t, s, a) {
      t.exports = a.p + 'assets/img/template-ft.4f6e0d14.png';
    },
    369: function(t, s, a) {
      t.exports = a.p + 'assets/img/template-bg.244b9ac7.png';
    },
    406: function(t, s, a) {
      'use strict';
      a.r(s);
      var e = a(42),
        r = Object(e.a)(
          {},
          function() {
            var t = this,
              s = t.$createElement,
              e = t._self._c || s;
            return e('ContentSlotsDistributor', { attrs: { 'slot-key': t.$parent.slotKey } }, [
              e('h2', { attrs: { id: '模板库实现思路' } }, [
                e('a', { staticClass: 'header-anchor', attrs: { href: '#模板库实现思路' } }, [
                  t._v('#'),
                ]),
                t._v(' 模板库实现思路'),
              ]),
              t._v(' '),
              e('p', [
                t._v(
                  '我们目前开放了模板库功能，一方面我们会定期配置行业模板，另一个方面Dooring还支持用户自己配置模板，可以一键保存到云端供用户使用。我们也可以将模板变成自己的页面共享给其他人。实现方式本质上是保存用户的配置信息，上传到服务器中做存储，在后台提供了管理模板的模块，可以修改，删除模板。如下图所示：',
                ),
              ]),
              t._v(' '),
              e('h3', { attrs: { id: '模板前台展示' } }, [
                e('a', { staticClass: 'header-anchor', attrs: { href: '#模板前台展示' } }, [
                  t._v('#'),
                ]),
                t._v(' 模板前台展示：'),
              ]),
              t._v(' '),
              e('img', { attrs: { src: a(368), alt: 'foo' } }),
              t._v(' '),
              e('h3', { attrs: { id: '模板后台展示' } }, [
                e('a', { staticClass: 'header-anchor', attrs: { href: '#模板后台展示' } }, [
                  t._v('#'),
                ]),
                t._v(' 模板后台展示：'),
              ]),
              t._v(' '),
              e('img', { attrs: { src: a(369), alt: 'foo' } }),
            ]);
          },
          [],
          !1,
          null,
          null,
          null,
        );
      s.default = r.exports;
    },
  },
]);
