(window.webpackJsonp = window.webpackJsonp || []).push([
  [9],
  {
    358: function(t, o, r) {
      t.exports = r.p + 'assets/img/logo.001d04e6.svg';
    },
    387: function(t, o, r) {
      'use strict';
      r.r(o);
      var s = r(42),
        v = Object(s.a)(
          {},
          function() {
            var t = this,
              o = t.$createElement,
              s = t._self._c || o;
            return s('ContentSlotsDistributor', { attrs: { 'slot-key': t.$parent.slotKey } }, [
              s('img', { attrs: { src: r(358), alt: 'foo' } }),
              t._v(' '),
              s('p', [
                t._v(
                  'H5-Dooring 是一款功能强大，高可扩展的 H5 可视化页面配置解决方案，致力于提供一套简单方便、专业可靠、无限可能的 H5 落地页最佳实践。',
                ),
              ]),
              t._v(' '),
              s('h2', { attrs: { id: '功能特点' } }, [
                s('a', { staticClass: 'header-anchor', attrs: { href: '#功能特点' } }, [t._v('#')]),
                t._v(' 功能特点'),
              ]),
              t._v(' '),
              s('p', [
                t._v('🎉 '),
                s('strong', [t._v('可扩展，')]),
                t._v(
                  ' Dooring 实现了较为完整的业务闭环，并使其模块化，编辑器内部功能接口也全部可以对接不同服务端语言，实现了标准化接口。此外还支持自定义组件，二次开发，设计模板等能力，以满足功能和跨领域的分层需求。',
                ),
              ]),
              t._v(' '),
              s('p', [
                t._v('📦 '),
                s('strong', [t._v('开箱即用，')]),
                t._v(' Dooring 内置了'),
                s('strong', [t._v('表单渲染器、页面渲染器、动态加载内核')]),
                t._v(
                  '等，仅需一套源码即可上手开发。并且还提供针对 React 的定制插件，内涵丰富的功能，可满足日常 80%的页面制作需求。',
                ),
              ]),
              t._v(' '),
              s('p', [
                t._v('🚀 '),
                s('strong', [t._v('大量自研，')]),
                t._v(
                  ' 包含整个编辑器架构、组件设计、文档、请求库封装，后台管理系统等，满足日常项目的周边需求。',
                ),
              ]),
              t._v(' '),
              s('p', [
                t._v('🚄 '),
                s('strong', [t._v('与时俱进，')]),
                t._v(' 在满足需求的同时，我们也不会停止对新技术的探索。比如更多'),
                s('strong', [
                  t._v('营销组件、业务功能，后台管理可视化，PC 页面编辑器，数据大屏定制'),
                ]),
                t._v('等等。'),
              ]),
              t._v(' '),
              s('h2', { attrs: { id: '为什么选择-dooring' } }, [
                s('a', { staticClass: 'header-anchor', attrs: { href: '#为什么选择-dooring' } }, [
                  t._v('#'),
                ]),
                t._v(' 为什么选择 Dooring'),
              ]),
              t._v(' '),
              s('p', [
                t._v('目前'),
                s('strong', [t._v('github')]),
                t._v(
                  '已超过 3000+star，上线 2 个月累计 500+用户使用，解决完善了 100+问题，后续会持续迭代，更新，自研优秀，先进的 lowcode/nocode 解决方案。',
                ),
              ]),
            ]);
          },
          [],
          !1,
          null,
          null,
          null,
        );
      o.default = v.exports;
    },
  },
]);
