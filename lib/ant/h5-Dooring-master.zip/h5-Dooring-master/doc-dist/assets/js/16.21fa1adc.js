(window.webpackJsonp = window.webpackJsonp || []).push([
  [16],
  {
    367: function(t, s, e) {
      t.exports = e.p + 'assets/img/framework.1c9c696b.png';
    },
    405: function(t, s, e) {
      'use strict';
      e.r(s);
      var n = e(42),
        o = Object(n.a)(
          {},
          function() {
            var t = this.$createElement,
              s = this._self._c || t;
            return s('ContentSlotsDistributor', { attrs: { 'slot-key': this.$parent.slotKey } }, [
              s('img', { attrs: { src: e(367), alt: 'foo' } }),
              this._v(' '),
              s('p', [this._v('注：灰色部分还未实现，正在更新中...')]),
            ]);
          },
          [],
          !1,
          null,
          null,
          null,
        );
      s.default = o.exports;
    },
  },
]);
