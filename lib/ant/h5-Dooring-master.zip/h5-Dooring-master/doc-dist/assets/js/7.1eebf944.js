(window.webpackJsonp = window.webpackJsonp || []).push([
  [7],
  {
    364: function(t, s, e) {
      t.exports = e.p + 'assets/img/preview-flow.b37c7798.png';
    },
    365: function(t, s, e) {
      t.exports = e.p + 'assets/img/preview-page.3ec86df5.png';
    },
    403: function(t, s, e) {
      'use strict';
      e.r(s);
      var r = e(42),
        a = Object(r.a)(
          {},
          function() {
            var t = this,
              s = t.$createElement,
              r = t._self._c || s;
            return r('ContentSlotsDistributor', { attrs: { 'slot-key': t.$parent.slotKey } }, [
              r('h1', { attrs: { id: '网页预览' } }, [
                r('a', { staticClass: 'header-anchor', attrs: { href: '#网页预览' } }, [t._v('#')]),
                t._v(' 网页预览'),
              ]),
              t._v(' '),
              r('p', [t._v('我们看看网页预览的工作流程：')]),
              t._v(' '),
              r('img', { attrs: { src: e(364), alt: 'foo' } }),
              t._v(' '),
              r('p', [t._v('前端预览界面：')]),
              t._v(' '),
              r('img', { attrs: { src: e(365), alt: 'foo' } }),
            ]);
          },
          [],
          !1,
          null,
          null,
          null,
        );
      s.default = a.exports;
    },
  },
]);
