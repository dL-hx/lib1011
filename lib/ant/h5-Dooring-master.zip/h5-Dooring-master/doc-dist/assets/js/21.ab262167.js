(window.webpackJsonp = window.webpackJsonp || []).push([
  [21],
  {
    385: function(t, e, n) {
      'use strict';
      n.r(e);
      var s = n(42),
        l = Object(s.a)(
          {},
          function() {
            var t = this.$createElement,
              e = this._self._c || t;
            return e('ContentSlotsDistributor', { attrs: { 'slot-key': this.$parent.slotKey } }, [
              e('p', [this._v('正在建设中...')]),
            ]);
          },
          [],
          !1,
          null,
          null,
          null,
        );
      e.default = l.exports;
    },
  },
]);
