(window.webpackJsonp = window.webpackJsonp || []).push([
  [15],
  {
    366: function(t, s, e) {
      t.exports = e.p + 'assets/img/screenshot.daeecedd.png';
    },
    404: function(t, s, e) {
      'use strict';
      e.r(s);
      var a = e(42),
        i = Object(a.a)(
          {},
          function() {
            var t = this.$createElement,
              s = this._self._c || t;
            return s('ContentSlotsDistributor', { attrs: { 'slot-key': this.$parent.slotKey } }, [
              s('h1', { attrs: { id: '截图功能' } }, [
                s('a', { staticClass: 'header-anchor', attrs: { href: '#截图功能' } }, [
                  this._v('#'),
                ]),
                this._v(' 截图功能'),
              ]),
              this._v(' '),
              s('p', [
                this._v(
                  '截图功能这里我们主要使用了dom-to-image这个库，来将html转化为图片，并进行分享。',
                ),
              ]),
              this._v(' '),
              s('img', { attrs: { src: e(366), alt: 'foo' } }),
            ]);
          },
          [],
          !1,
          null,
          null,
          null,
        );
      s.default = i.exports;
    },
  },
]);
