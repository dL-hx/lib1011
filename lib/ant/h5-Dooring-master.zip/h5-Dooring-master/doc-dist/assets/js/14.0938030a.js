(window.webpackJsonp = window.webpackJsonp || []).push([
  [14],
  {
    362: function(t, e, s) {
      t.exports = s.p + 'assets/img/preview-machine.895a0711.png';
    },
    398: function(t, e, s) {
      'use strict';
      s.r(e);
      var a = s(42),
        n = Object(a.a)(
          {},
          function() {
            var t = this,
              e = t.$createElement,
              a = t._self._c || e;
            return a('ContentSlotsDistributor', { attrs: { 'slot-key': t.$parent.slotKey } }, [
              a('h1', { attrs: { id: '真机预览' } }, [
                a('a', { staticClass: 'header-anchor', attrs: { href: '#真机预览' } }, [t._v('#')]),
                t._v(' 真机预览'),
              ]),
              t._v(' '),
              a('p', [t._v('真机预览和网页预览的流程类似，工作流程如下：')]),
              t._v(' '),
              a('img', { attrs: { src: s(362), alt: 'foo' } }),
              t._v(' '),
              a('p', [t._v('由于不同机型预览的效果有些许不同，最终效果以实际看到的为主。')]),
            ]);
          },
          [],
          !1,
          null,
          null,
          null,
        );
      e.default = n.exports;
    },
  },
]);
