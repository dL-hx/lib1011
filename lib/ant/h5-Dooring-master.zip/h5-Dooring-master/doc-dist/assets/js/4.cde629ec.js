(window.webpackJsonp = window.webpackJsonp || []).push([
  [4],
  {
    333: function(t, e, n) {},
    373: function(t, e, n) {
      'use strict';
      n(333);
    },
    408: function(t, e, n) {
      'use strict';
      n.r(e);
      var i = {
          functional: !0,
          props: {
            type: { type: String, default: 'tip' },
            text: String,
            vertical: { type: String, default: 'top' },
          },
          render: function(t, e) {
            var n = e.props,
              i = e.slots;
            return t(
              'span',
              { class: ['badge', n.type], style: { verticalAlign: n.vertical } },
              n.text || i().default,
            );
          },
        },
        r = (n(373), n(42)),
        p = Object(r.a)(i, void 0, void 0, !1, null, '15b7b770', null);
      e.default = p.exports;
    },
  },
]);
