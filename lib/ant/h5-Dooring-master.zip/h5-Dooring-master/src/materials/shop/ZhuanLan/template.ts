const template = {
  type: 'ZhuanLan',
  h: 120,
  displayName: '专栏组件',
};
export default template;
