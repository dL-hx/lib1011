const template = {
  type: 'Coupons',
  h: 72,
  displayName: '优惠券组件',
};
export default template;
