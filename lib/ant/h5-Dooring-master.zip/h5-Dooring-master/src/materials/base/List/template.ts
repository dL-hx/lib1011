const template = {
  type: 'List',
  h: 110,
  displayName: '列表组件',
};
export default template;
