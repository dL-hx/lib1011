const template = {
  type: 'LongText',
  h: 36,
  displayName: '长文本组件',
};
export default template;
