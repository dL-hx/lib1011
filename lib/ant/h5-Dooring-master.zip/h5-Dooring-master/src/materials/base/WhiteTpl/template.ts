const template = {
  type: 'WhiteTpl',
  h: 20,
  displayName: '空白组件',
};
export default template;
