const template = {
  type: 'Audio',
  h: 48,
  displayName: '音频组件',
};
export default template;
