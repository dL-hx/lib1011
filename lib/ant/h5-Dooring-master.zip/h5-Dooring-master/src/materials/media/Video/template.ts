const template = {
  type: 'Video',
  h: 107,
  displayName: '视频组件',
};
export default template;
