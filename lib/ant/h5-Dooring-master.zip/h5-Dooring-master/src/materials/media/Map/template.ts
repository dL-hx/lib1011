const template = {
  type: 'Map',
  h: 120,
  displayName: '地图组件',
};
export default template;
