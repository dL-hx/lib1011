import React from 'react';

export default () => <div className="rotate-animate">Dooring</div>;
