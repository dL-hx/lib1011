import useFullscreen from '../index';

describe('useFullscreen', () => {
  it('should be defined', () => {
    expect(useFullscreen).toBeDefined();
  });
});
