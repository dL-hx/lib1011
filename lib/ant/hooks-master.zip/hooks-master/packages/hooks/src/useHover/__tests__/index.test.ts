// write your test cases here
import useHover from '../index';

describe('useHover', () => {
  it('should be defined', () => {
    expect(useHover).toBeDefined();
  });
});
