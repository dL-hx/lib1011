import useNetwork from '../index';

// const setUp = () => renderHook(() => useNetwork());

describe('useNetwork', () => {
  it('should be defined', () => {
    expect(useNetwork).toBeDefined();
  });
});
