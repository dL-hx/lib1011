export interface ThrottleOptions {
  wait?: number;
  leading?: boolean;
  trailing?: boolean;
}
