import useExternal from '../index';
import { renderHook } from '@testing-library/react-hooks';

describe('useExternal', () => {
  it('should be defined', () => {
    expect(useExternal).toBeDefined();
  });
});
