export interface DebounceOptions {
  wait?: number;
  leading?: boolean;
  trailing?: boolean;
}
