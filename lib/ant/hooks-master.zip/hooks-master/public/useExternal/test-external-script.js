window.TEST_SCRIPT = {
  start: function () {
    return 'Hello World';
  },
};
