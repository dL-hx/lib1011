# @ant-design/pro-skeleton

> @ant-design/pro-skeleton.

See our website [@ant-design/pro-skeleton](https://procomponent.ant.design/) for more information.

## Install

Using npm:

```bash
$ npm install --save  @ant-design/pro-skeleton
```

or using yarn:

```bash
$ yarn add @ant-design/pro-skeleton
```
