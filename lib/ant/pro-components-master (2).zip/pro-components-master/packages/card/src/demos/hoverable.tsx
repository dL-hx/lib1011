import React from 'react';
import ProCard from '@ant-design/pro-card';

export default () => {
  return (
    <>
      <ProCard style={{ maxWidth: 300 }} hoverable bordered>
        内容
      </ProCard>
    </>
  );
};
