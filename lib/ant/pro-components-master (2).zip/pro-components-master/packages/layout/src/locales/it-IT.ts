import settingDrawer from './it-IT/settingDrawer';

export default {
  ...settingDrawer,
};
