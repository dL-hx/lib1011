import settingDrawer from './en-US/settingDrawer';

export default {
  ...settingDrawer,
};
