declare module '*.module.less';

interface Window {
  DarkReader: any;
}
