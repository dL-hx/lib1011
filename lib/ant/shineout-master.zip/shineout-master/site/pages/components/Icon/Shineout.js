import { Icon } from 'shineout'

const url = '//at.alicdn.com/t/font_1070077_6cete9az955.css'
export default Icon(url, 'iconfont', 'icon')
