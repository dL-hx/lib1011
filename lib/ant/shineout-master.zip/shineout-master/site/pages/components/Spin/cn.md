# Spin *加载中*

部分样式来源于[SpinKit](https://github.com/tobiasahlin/SpinKit)

<example />

## API

| 属性 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| color | string | #6c757d | 颜色 |
| size | number \| string | 40 | 尺寸 |
| name | string | 'fading-circle' | 类型，可选值见示例 |