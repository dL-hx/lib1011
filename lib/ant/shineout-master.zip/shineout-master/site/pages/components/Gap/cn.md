# Gap *间距*

<example />

## API

| 属性 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| className | string | 无 | 扩展className |
| style | object | 无 | 自定义样式 |
| row | number \| string | 8 | 垂直方向的行间距 |
| column | number \| string | 8 | 水平方向的列间距 |
| itemStyle | object | 无 | 子元素自定义样式 |