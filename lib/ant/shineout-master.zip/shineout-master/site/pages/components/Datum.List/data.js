export default {
  red: { id: 1, name: 'red' },
  orange: { id: 2, name: 'orange' },
  yellow: { id: 3, name: 'yellow' },
  green: { id: 4, name: 'green' },
  cyan: { id: 5, name: 'cyan' },
  blue: { id: 6, name: 'blue' },
  violet: { id: 7, name: 'violet' },
}
