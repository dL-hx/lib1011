import './pages/components/Carousel/style-2-custom-indicator.less'
