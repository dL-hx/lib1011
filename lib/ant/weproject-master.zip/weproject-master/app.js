App({
    config: { //注意这个是我自定义的，通过getapp()可以去到他的值
      apiBase: 'https://locally.uieee.com'
    }
  })