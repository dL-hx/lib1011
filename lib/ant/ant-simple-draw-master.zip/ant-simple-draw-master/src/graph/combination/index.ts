import { shapeName } from '@/config';
export const graphic = {
  shape: shapeName.flowChartImageRect,
};

export default { graphic };
