export interface tempalteType {
  id?: string;
  type: string;
  title: string;
  category?: string;
}
