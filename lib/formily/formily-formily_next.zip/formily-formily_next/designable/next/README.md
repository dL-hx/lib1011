# @formily/designable-next

### Install

```bash
npm install --save @formily/designable-next
```
