import { runCopy } from '../../scripts/build-style'

runCopy({
  esStr: '@alifd/next/es/',
  libStr: '@alifd/next/lib/',
})
