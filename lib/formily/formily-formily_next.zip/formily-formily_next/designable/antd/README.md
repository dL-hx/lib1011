# @formily/designable-antd

### Install

```bash
npm install --save @formily/designable-antd
```
