import { ArrayTable } from './ArrayTable'
import { Card } from './Card'

export const ArrayCards = Card
ArrayCards.Addition = ArrayTable.Addition
