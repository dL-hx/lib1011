import { runCopy } from '../../scripts/build-style'

runCopy({
  esStr: 'antd/es/',
  libStr: 'antd/lib/',
})
