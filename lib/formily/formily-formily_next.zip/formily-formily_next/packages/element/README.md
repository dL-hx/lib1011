# @formily/element

### Requirement

vue^2.6.0 + @vue/composition-api^1.0.0-beta.1

### Install

```bash
npm install --save @formily/element
```
