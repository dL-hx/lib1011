module.exports = require('../../scripts/jest.base')
