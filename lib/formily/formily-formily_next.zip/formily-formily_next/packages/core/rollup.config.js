import baseConfig from '../../scripts/rollup.base.js'

export default baseConfig('formily.core', 'Formily.Core')
