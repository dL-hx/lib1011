import { Space } from 'antd'

export { Space }

export default Space
