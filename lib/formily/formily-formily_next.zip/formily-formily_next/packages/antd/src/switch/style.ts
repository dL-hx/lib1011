import 'antd/lib/switch/style/index'
