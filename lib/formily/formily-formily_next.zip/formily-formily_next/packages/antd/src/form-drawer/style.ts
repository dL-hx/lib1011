import 'antd/lib/drawer/style/index'
