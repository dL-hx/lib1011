import 'antd/lib/time-picker/style/index'
