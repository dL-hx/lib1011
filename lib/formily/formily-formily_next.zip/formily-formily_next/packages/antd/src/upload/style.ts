import 'antd/lib/upload/style/index'
