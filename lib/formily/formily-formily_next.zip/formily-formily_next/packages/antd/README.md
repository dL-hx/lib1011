# @formily/antd

### Install

```bash
npm install --save @formily/antd
```
