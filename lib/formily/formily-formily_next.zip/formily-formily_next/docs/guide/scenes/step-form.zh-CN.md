# 分步表单

主要使用[@formily/antd](https://antd.formilyjs.org) 或 [@formily/next](https://next.formilyjs.org) 中的[FormStep](https://antd.formilyjs.org/components/form-step)组件
