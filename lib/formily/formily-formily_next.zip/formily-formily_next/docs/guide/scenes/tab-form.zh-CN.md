# 选项卡/手风琴表单

主要使用[@formily/antd](https://antd.formilyjs.org) 或 [@formily/next](https://next.formilyjs.org) 中的[FormTab](https://antd.formilyjs.org/components/form-tab)组件 与 [FormCollapse](https://antd.formilyjs.org/components/form-collapse)组件
