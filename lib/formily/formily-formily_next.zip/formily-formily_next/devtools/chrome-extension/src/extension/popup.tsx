import React from 'react'
import ReactDOM from 'react-dom'

ReactDOM.render(<div>hello world</div>, document.getElementById('root'))
