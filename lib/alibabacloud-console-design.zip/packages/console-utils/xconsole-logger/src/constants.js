export const SPMA = '5176'
export const GOLDLOG_SETPAGESPM = 'goldlog.setPageSPM'
export const GOLDLOG_SENDPV = 'goldlog.sendPV'

