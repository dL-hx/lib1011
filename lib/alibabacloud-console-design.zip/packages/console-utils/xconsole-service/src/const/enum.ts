export enum ApiType {
  plugin = "plugin",
  inner="inner",
  app = "app",
  open = "open",
  roa = "roa",
  custom = "custom",
}
