const defaultOption = {
  onError: (e: Error): void => {
    // Empty
  },
  ignoreError: false,
}

export default defaultOption;