import ConsoleConfig from './ConsoleConfig';
export { default as ConsoleBase } from './ConsoleBase';

export default new ConsoleConfig();
