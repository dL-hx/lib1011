# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

<a name="1.0.16"></a>
## [1.0.16](https://gitlab.alibaba-inc.com/wind-pro/wind-pro-rc-component/compare/@ali/wind-pro-context@1.0.16-alpha.0...@ali/wind-pro-context@1.0.16) (2019-07-05)




**Note:** Version bump only for package @ali/wind-pro-context

<a name="1.0.14"></a>
## [1.0.14](https://gitlab.alibaba-inc.com/wind-pro/wind-pro-rc-component/compare/@ali/wind-pro-context@1.0.13...@ali/wind-pro-context@1.0.14) (2019-06-05)




**Note:** Version bump only for package @ali/wind-pro-context
