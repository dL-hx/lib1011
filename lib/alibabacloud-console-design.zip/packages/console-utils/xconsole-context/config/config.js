module.exports = {
  presets: [
    [
      '@alicloud/console-toolkit-preset-wind-component',
      {
        useTypescript: true,
        moduleName: 'XConsoleContext',
      },
    ],
  ],
};
