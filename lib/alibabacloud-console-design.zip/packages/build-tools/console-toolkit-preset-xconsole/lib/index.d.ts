declare const _default: (config: any, args: any) => {
    plugins: (string | any[])[];
};
export default _default;
