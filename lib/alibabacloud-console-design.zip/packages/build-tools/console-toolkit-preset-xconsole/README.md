# `breezr-plugin-webpack`

> TODO: description

## Usage

##### Install deps

```shell
yarn install
```

##### Run Test

```shell
yarn test
```
