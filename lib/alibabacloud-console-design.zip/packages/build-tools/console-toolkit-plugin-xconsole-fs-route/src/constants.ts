export const SYTLE = 'index.scoped.less';

export const COMPONENT_ENTRY = 'index.js';

export const CONFIG = 'config.js';

export const MODEL = 'model.js';

export const TMP_DIR = '.xconsole';

export const IGNORE_DIR = ['modules'];

export const GLOBAL_DIR = 'global';

export const LAYOUT = 'layout';
