declare module 'esprima-extract-comments';
