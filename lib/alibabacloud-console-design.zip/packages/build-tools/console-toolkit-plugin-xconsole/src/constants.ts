export const GENERATOR_URL = 'git@gitlab.alibaba-inc.com:xconsole/xconsole-example';
