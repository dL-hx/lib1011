# XConsole

## 开发

```bash
git clone [你的git仓库]
cd [你的本地目录]
npm i
npm run start -- --port 3333
```
