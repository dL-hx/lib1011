import { PluginAPI } from '@alicloud/console-toolkit-core';
export default function (api: PluginAPI): void;
