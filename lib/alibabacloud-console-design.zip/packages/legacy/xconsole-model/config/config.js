module.exports = {
  presets: [
    [
      "@alicloud/console-toolkit-preset-wind-component",
      {
        moduleName: "@alicloud/xconsole-model",
      }
    ]
  ]
};
