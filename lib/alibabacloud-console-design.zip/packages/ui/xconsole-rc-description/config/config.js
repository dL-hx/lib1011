module.exports = {
  presets: [
    [
      "@alicloud/console-toolkit-preset-wind-component",
      {
        moduleName: "XconsoleRcDescription",
        useTypescript: true
      }
    ]
  ]
};
