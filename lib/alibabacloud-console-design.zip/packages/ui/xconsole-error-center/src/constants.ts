export const FoundRiskAndDoubleConfirm = 'FoundRiskAndDoubleConfirm';
export const ConsoleNeedLogin = 'ConsoleNeedLogin';
export const PostonlyOrTokenError = 'PostonlyOrTokenError';