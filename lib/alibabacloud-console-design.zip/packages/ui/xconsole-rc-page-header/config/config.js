module.exports = {
  presets: [
    [
      '@alicloud/console-toolkit-preset-wind-component',
      {
        moduleName: '@alicloud/xconsole-rc-page-header',
        useTypescript: true,
      },
    ],
  ],
};
