# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

<a name="1.1.2"></a>
## [1.1.2](https://gitlab.alibaba-inc.com/wind-pro/wind-pro-rc-component/compare/@ali/wind-pro-rc-app-layout@1.1.2-alpha.2...@ali/wind-pro-rc-app-layout@1.1.2) (2019-07-05)




**Note:** Version bump only for package @ali/wind-pro-rc-app-layout

<a name="1.1.0"></a>
# [1.1.0](https://gitlab.alibaba-inc.com/wind-pro/wind-pro-rc-component/compare/@ali/wind-pro-rc-app-layout@1.0.9...@ali/wind-pro-rc-app-layout@1.1.0) (2019-06-10)


### Features

* collapsed & dynamic path match ([38d370b](https://gitlab.alibaba-inc.com/wind-pro/wind-pro-rc-component/commit/38d370b))




<a name="1.0.9"></a>
## [1.0.9](https://gitlab.alibaba-inc.com/wind-pro/wind-pro-rc-component/compare/@ali/wind-pro-rc-app-layout@1.0.8...@ali/wind-pro-rc-app-layout@1.0.9) (2019-06-05)




**Note:** Version bump only for package @ali/wind-pro-rc-app-layout
