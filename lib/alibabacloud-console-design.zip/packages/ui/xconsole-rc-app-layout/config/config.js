module.exports = {
  presets: [
    [
      '@alicloud/console-toolkit-preset-wind-component',
      {
        moduleName: '@alicloud/xconsole-rc-app-layout',
        useTypescript: true,
      },
    ],
  ],
};
