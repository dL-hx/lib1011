export const baseClassName = 'wind-rc-link'

export const nextClassName = 'next'

export const btnClassName = 'next-btn'
