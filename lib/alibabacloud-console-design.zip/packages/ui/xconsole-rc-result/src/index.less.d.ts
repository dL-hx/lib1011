export const xc_rc_result: string;
export const xc_rc_result_description: string;
export const xc_rc_result_actions: string;
export const xc_rc_result_extra: string;
export const xc_rc_result_children: string;