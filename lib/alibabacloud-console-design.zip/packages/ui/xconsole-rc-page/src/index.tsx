import Page from './Page';

export { Menu } from '@alicloud/console-components-page';
export default Page;
