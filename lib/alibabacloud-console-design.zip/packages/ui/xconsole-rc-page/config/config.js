module.exports = {
  presets: [
    [
      '@alicloud/console-toolkit-preset-wind-component',
      {
        moduleName: 'XconsoleRcPage',
        useTypescript: true,
        useTerserPlugin: true,
      },
    ],
  ],
};
