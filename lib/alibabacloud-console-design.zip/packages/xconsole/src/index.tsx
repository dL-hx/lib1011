import XConsoleApp from './app';

export { AppConfig } from './types/AppConfig';

export default XConsoleApp;

// 为了兼容 1.x
export * from './utils/index';
export * from './ui/index';