export {
  useService,
  useOpenApi,
  useInnerApi,
  usePluginApi,
  useAppApi, // @ts-ignore
} from '@alicloud/xconsole-service';
