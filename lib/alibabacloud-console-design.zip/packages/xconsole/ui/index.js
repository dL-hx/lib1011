import '@alicloud/console-components/dist/xconsole.css';

export * from '../lib/ui'