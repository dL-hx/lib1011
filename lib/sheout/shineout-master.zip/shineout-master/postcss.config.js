module.exports = {
  plugins: {
    autoprefixer: {
      browsers: ['ie 10'],
    },
  },
}
