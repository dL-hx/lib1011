import { Icon } from 'shineout'

export default Icon('//at.alicdn.com/t/font_550076_jy6we81tkk.css', 'docs', 'docs')
