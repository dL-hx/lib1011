import { Icon } from 'shineout'

const url = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'
export default Icon(url, 'FontAwesome', 'fa')
