# Spin

Part of the style comes from [SpinKit](https://github.com/tobiasahlin/SpinKit).

<example />

## API

| Property | Type | Default | Description |
| --- | --- | --- | --- |
| color | string | #6c757d | color |
| size | number \| string | 40 | size |
| tip | string  \| ReactNode | - | custom tip |
| name | string | 'fading-circle' | type. See the example for optional values. |
