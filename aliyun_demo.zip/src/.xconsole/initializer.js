import { intl } from '@alicloud/xconsole'
import messages from '~/locales/messages'

intl.set({ messages })
