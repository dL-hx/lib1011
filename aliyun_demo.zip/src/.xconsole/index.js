import { mount } from '@alicloud/console-os-react-portal';
import './initializer'
import App from './app'


let dom = document.getElementById('app');
if (!dom) {
  dom = document.createElement('div');
  document.body.append(dom)
  dom.id = '--aliyun-xconsole-app'
}

export default mount(
  App,
  dom,
  'os-app'
);
