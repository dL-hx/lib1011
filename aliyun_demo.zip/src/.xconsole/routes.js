import React from 'react';
import XConsoleApp from '@alicloud/xconsole'
import sidebar from '~/sidebar'

import { AppLayout } from '@alicloud/xconsole/ui'


import appConfig from '~/appConfig';

import routeConfig from './route_config';



export default (config = {}) => () => (
  <XConsoleApp {...{
    sidebar,
    routeConfig,
    AppLayout,
    appConfig,
    ...config
  }} />);
