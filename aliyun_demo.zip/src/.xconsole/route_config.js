
import PagesTechService from '../pages/tech/service/index'
import PagesTechResource_16_group from '../pages/tech/resource-group/index'
import PagesTechConsole_17_config from '../pages/tech/console-config/index'
import PagesTech_18_regionId from '../pages/tech/$regionId/index'
import PagesTab_19_profile_19_section from '../pages/tab-profile/$section/index'
import PagesSuccess_20_result from '../pages/success-result/index'
import PagesRoute_21_list_21_id_21_section from '../pages/route-list/$id/$section/index'
import PagesRoute_22_list from '../pages/route-list/index'
import PagesOverview from '../pages/overview/index'
import PagesFail_24_result from '../pages/fail-result/index'
import PagesConsole_25_chart from '../pages/console-chart/index'
import PagesBasic_26_profile from '../pages/basic-profile/index'
import PagesBasic_27_form from '../pages/basic-form/index'
import Pages_28_regonIdBasic_28_list from '../pages/$regonId/basic-list/index'
export default{
  global: {
    "hasUIConfig": false,
    "hasWidgetLoader": false,
    "hasEntryCode": false,
    "hasAppConfig": true,
    "hasLayout": false,
    "indexRoute": "basic-list",
    "prefix": "",
    "mode": "browser",
    "appId": "os-app",
    "redirect": "basic-list"
},
  routes: [
    {
      path: 'tech/service',
      component: PagesTechService,
      layout: null,
      config: {}
    },
{
      path: 'tech/resource-group',
      component: PagesTechResource_16_group,
      layout: null,
      config: {}
    },
{
      path: 'tech/console-config',
      component: PagesTechConsole_17_config,
      layout: null,
      config: {}
    },
{
      path: 'tech/:regionId',
      component: PagesTech_18_regionId,
      layout: null,
      config: {}
    },
{
      path: 'tab-profile/:section',
      component: PagesTab_19_profile_19_section,
      layout: null,
      config: {
        "eslint react/prop-types": 0
}
    },
{
      path: 'success-result',
      component: PagesSuccess_20_result,
      layout: null,
      config: {}
    },
{
      path: 'route-list/:id/:section',
      component: PagesRoute_21_list_21_id_21_section,
      layout: null,
      config: {
        "eslint react/prop-types": 0
}
    },
{
      path: 'route-list',
      component: PagesRoute_22_list,
      layout: null,
      config: {}
    },
{
      path: 'overview',
      component: PagesOverview,
      layout: null,
      config: {}
    },
{
      path: 'fail-result',
      component: PagesFail_24_result,
      layout: null,
      config: {}
    },
{
      path: 'console-chart',
      component: PagesConsole_25_chart,
      layout: null,
      config: {}
    },
{
      path: 'basic-profile',
      component: PagesBasic_26_profile,
      layout: null,
      config: {}
    },
{
      path: 'basic-form',
      component: PagesBasic_27_form,
      layout: null,
      config: {}
    },
{
      path: ':regonId/basic-list',
      component: Pages_28_regonIdBasic_28_list,
      layout: null,
      config: {}
    }
  ]
};